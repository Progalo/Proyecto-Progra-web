import React from 'react';
import '../componentes/Header.css'

function Header(){
    return(
        <div className='header'>
            <div className='header-text'>
                <h1>TIENDA</h1>
            </div>
        </div>
    )
}

export default Header